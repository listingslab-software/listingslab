![Logo](./media/svg/avatars/chix.svg)  
## @listingslab WordPress Plugin

#### Aims & Goals 

To be included in the [WordPress Plgin Directory](./md/030_wp_plugin_directory.md) so that it returns in the [search](https://wordpress.org/plugins/search/listingslab/). To do so it must meet these [guidelines](./md/020_wp_plugin_guidelines.md)

#### Description

It's a Plugin which takes any tired old WordPress site and magically turns it into a way superior React Progressive Web App 
