
## Install

#### Symlink 

Symlink this repo into your WordPress using this command

```bash
cd <working-dir>
git clone https://github.com/listingslab-software/listingslab
cd listingslab
ln -s <working-dir>/listingslab/ <wp-install>/wp-content/plugins/
```