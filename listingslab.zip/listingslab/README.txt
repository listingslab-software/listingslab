=== @listingslab ===
Contributors: listingslab
Tags: pwa, react
Requires at least: 5.6
Tested up to: 5.6
Requires PHP: 5.6.20
Stable tag: 14.0.1
License: MIT
License URI: https://opensource.org/licenses/MIT

Magically turns it into a way superior React Progressive Web App

== Description ==
It\'s a Plugin which takes any tired old WordPress site and magically turns it into a way superior React Progressive Web App 

https://developer.wordpress.org/plugins/wordpress-org/how-your-readme-txt-works/